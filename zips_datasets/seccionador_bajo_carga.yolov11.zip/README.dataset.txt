# seccionador_bajo_carga > seccionador_bajo_carga-tfylf
https://universe.roboflow.com/tomass-workspace-glzow/seccionador_bajo_carga-tfylf

Provided by a Roboflow user
License: CC BY 4.0

