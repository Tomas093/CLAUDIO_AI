# Instrumento_de_medicion_multifun > instrumento_de_medicion_multifun
https://universe.roboflow.com/tomass-workspace-glzow/instrumento_de_medicion_multifun

Provided by a Roboflow user
License: CC BY 4.0

