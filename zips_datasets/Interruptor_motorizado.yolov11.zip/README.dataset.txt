# Interruptor_motorizado. > interruptor_motorizado
https://universe.roboflow.com/tomass-workspace-glzow/interruptor_motorizado

Provided by a Roboflow user
License: CC BY 4.0

