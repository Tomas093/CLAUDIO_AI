# Tablero_de_transferencia_automat > tablero_de_transferencia_automat
https://universe.roboflow.com/tomass-workspace-glzow/tablero_de_transferencia_automat

Provided by a Roboflow user
License: CC BY 4.0

