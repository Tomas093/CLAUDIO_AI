# grupo_electrogeno > grupo_electrogeno
https://universe.roboflow.com/tomass-workspace-glzow/grupo_electrogeno

Provided by a Roboflow user
License: CC BY 4.0

