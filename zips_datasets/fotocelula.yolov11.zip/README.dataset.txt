# fotocelula > fotocelula
https://universe.roboflow.com/tomass-workspace-glzow/fotocelula

Provided by a Roboflow user
License: CC BY 4.0

