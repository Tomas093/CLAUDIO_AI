# Interruptor_temporizado > interruptor_temporizado
https://universe.roboflow.com/tomass-workspace-glzow/interruptor_temporizado

Provided by a Roboflow user
License: CC BY 4.0

