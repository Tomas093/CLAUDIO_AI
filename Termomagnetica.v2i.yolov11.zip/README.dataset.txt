# Termomagnetica > 2026-08-24 9:07pm
https://universe.roboflow.com/bitana/termomagnetica

Provided by a Roboflow user
License: CC BY 4.0

